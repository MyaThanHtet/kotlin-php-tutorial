<?php


       include_once("config.php");
      
			
	        $query= "SELECT * FROM user";

			 if(mysqli_query($con,$query)){
			    
	                     $result= mysqli_query($con, $query);
		             $emparray = array();
	                     if(mysqli_num_rows($result) > 0){  
	                     while ($row = mysqli_fetch_assoc($result)) {
                                     $emparray[] = $row;
                                   }
	                     }
			    echo json_encode( $emparray );
		 	 }else{
		 		 echo json_encode(array( "status" => "false","message" => "Error occured, please try again!") );
		 	}
	     mysqli_close($con);
     
 
 ?>