<?php
$host="localhost";
$user="id18113856_mya";
$password="^J)rAO/~)/U5GicA";
$db = "id18113856_dbmya";

$con = mysqli_connect($host,$user,$password,$db);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }else{  //echo "Connect"; 
  

   }

?>