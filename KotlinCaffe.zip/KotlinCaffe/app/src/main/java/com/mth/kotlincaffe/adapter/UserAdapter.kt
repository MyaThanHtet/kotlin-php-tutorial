package com.mth.kotlincaffe.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mth.kotlincaffe.R
import com.mth.kotlincaffe.entity.User

class UserAdapter(private val userList: MutableList<User>) :
    RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.user_list_item, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserAdapter.ViewHolder, position: Int) {
        val user = userList[position]
        holder.idTv.text = user.id
        holder.usernameTv.text = user.name
        holder.hobbyTv.text = user.hobby
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val idTv: TextView = itemView.findViewById(R.id.id)
        val usernameTv: TextView = itemView.findViewById(R.id.username)
        val hobbyTv: TextView = itemView.findViewById(R.id.hobby)
    }
}