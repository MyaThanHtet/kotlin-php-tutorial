package com.mth.kotlincaffe.entity

data class User(
    var id:String,
    var name: String,
    var username: String,
    var password: String,
    var hobby: String
)