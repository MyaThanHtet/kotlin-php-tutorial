package com.mth.kotlincaffe.ui

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.mth.kotlincaffe.R
import android.widget.TextView
import android.content.Intent

import com.mth.kotlincaffe.MainActivity


class WelcomeActivity : AppCompatActivity() {

    private lateinit var tvname: TextView
    private lateinit var tvhobby: TextView
    private lateinit var btnlogout: Button
    private lateinit var btnViewUer: Button
    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.welcome_layout)
        preferenceHelper = PreferenceHelper(this);
        tvhobby = findViewById(R.id.tvhobby)
        btnlogout = findViewById(R.id.btn)
        tvname = findViewById(R.id.tvname)
        btnViewUer = findViewById(R.id.btnUserList)
        tvname.setText("Welcome ${preferenceHelper.name}")
        tvhobby.setText("Your hobby is ${preferenceHelper.hobby}")

        btnlogout.setOnClickListener {
            preferenceHelper.putIsLogin(false)
            val intent = Intent(this@WelcomeActivity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
        btnViewUer.setOnClickListener {
            val intent = Intent(this@WelcomeActivity, UserListActivity::class.java)
            startActivity(intent)
        }

    }
}