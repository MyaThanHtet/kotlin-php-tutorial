package com.mth.kotlincaffe.ui

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.GsonBuilder
import com.mth.kotlincaffe.R
import com.mth.kotlincaffe.adapter.UserAdapter
import com.mth.kotlincaffe.entity.User
import com.mth.kotlincaffe.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class UserListActivity : AppCompatActivity() {
    private lateinit var userRecyclerView: RecyclerView
    private lateinit var userAdapter: UserAdapter

    private var listUsers: MutableList<User> = mutableListOf<User>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.userlist_activity)
        userRecyclerView = findViewById(R.id.user_recyclerview)
        userRecyclerView.layoutManager = LinearLayoutManager(this)
        listUsers = mutableListOf()
        userAdapter = UserAdapter(listUsers)
        userRecyclerView.adapter = userAdapter
        fetchData()
    }

    private fun fetchData() {
        var gson = GsonBuilder()
            .setLenient()
            .create()
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://myatech.000webhostapp.com")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
        val api: RetrofitClient = retrofit.create(RetrofitClient::class.java)
        val call: Call<MutableList<User>> = api.getUserList()

        call.enqueue(object : Callback<MutableList<User>> {
            override fun onResponse(
                call: Call<MutableList<User>>,
                response: Response<MutableList<User>>
            ) {
                val usersResponse = response.body()
                Log.i("USERRESONSE", usersResponse.toString())
                listUsers.clear()
                usersResponse?.let { listUsers.addAll(it) }
                userAdapter.notifyDataSetChanged()
            }

            override fun onFailure(call: Call<MutableList<User>>, t: Throwable) {
                Log.i("USERRESONSE", "fail : $t")

            }


        })
    }
}