package com.mth.kotlincaffe.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mth.kotlincaffe.R
import com.mth.kotlincaffe.MainActivity

import android.content.Intent
import android.util.Log
import com.mth.kotlincaffe.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import org.json.JSONException

import android.widget.Toast
import com.mth.kotlincaffe.network.ServiceBuilder

import org.json.JSONObject


class LoginActivity : AppCompatActivity() {
    private lateinit var etUname: EditText
    private lateinit var etPass: EditText
    private lateinit var btnlogin: Button
    private lateinit var tvreg: TextView
    private lateinit var preferenceHelper: PreferenceHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etUname = findViewById(R.id.etusername)
        etPass = findViewById(R.id.etpassword)
        btnlogin = findViewById(R.id.btn)
        tvreg = findViewById(R.id.tvreg)
        preferenceHelper = PreferenceHelper(this);
        tvreg.setOnClickListener {
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        btnlogin.setOnClickListener {
            loginUser()
        }
    }

    private fun loginUser() {
        val username = etUname.text.toString().trim { it <= ' ' }
        val password = etPass.text.toString().trim { it <= ' ' }
        Toast.makeText(applicationContext, "$username + $password", Toast.LENGTH_SHORT).show()

        val retrofit = ServiceBuilder.buildService(RetrofitClient::class.java)

        retrofit.getUserLogin(username, password).enqueue(
            object : Callback<String> {
                override fun onFailure(call: Call<String>, t: Throwable) {
                    Log.i(LoginActivity::class.simpleName, "on FAILURE!!!!$t")
                }

                override fun onResponse(call: Call<String>, response: Response<String>) {

                    val jsonresponse: String = response.body().toString()
                    parseLoginData(jsonresponse)
                    Log.i("RETROFITRESULT", jsonresponse)
                }
            }
        )

        /*val retro = Retrofit.Builder()
            .baseUrl("http://myatech.000webhostapp.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retro.create(RetrofitClient::class.java)
        val loginRequest = service.getUserLogin(username, password)

        loginRequest?.enqueue(object : Callback<String?> {
            override fun onResponse(call: Call<String?>, response: Response<String?>) {
                Log.i("Responsestring", response.body().toString())

                if (response.isSuccessful)
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString())
                        *//*        String jsonresponse = response.body().toString();
                        parseLoginData(jsonresponse);*//*

                        val jsonresponse: String = response.body().toString()
                        parseLoginData(jsonresponse)
                    }
            }

            override fun onFailure(call: Call<String?>, t: Throwable) {
                Log.i(LoginActivity::class.simpleName, "on FAILURE!!!!$t")
            }

        })*/

    }

    private fun parseLoginData(response: String) {
        try {

            val jsonObject = JSONObject(response)
            Toast.makeText(applicationContext, jsonObject.getString("status"), Toast.LENGTH_SHORT)
                .show()
            if (jsonObject.getString("status") == "true") {
                saveInfo(response)
                Toast.makeText(this@LoginActivity, "Login Successfully!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@LoginActivity, WelcomeActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish()
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    private fun saveInfo(response: String) {
        preferenceHelper.putIsLogin(true)
        try {
            val jsonObject = JSONObject(response)
            if (jsonObject.getString("status") == "true") {
                val dataArray = jsonObject.getJSONArray("data")
                for (i in 0 until dataArray.length()) {
                    val dataObj = dataArray.getJSONObject(i)
                    preferenceHelper.putName(dataObj.getString("name"))
                    preferenceHelper.putHobby(dataObj.getString("hobby"))
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }
}



