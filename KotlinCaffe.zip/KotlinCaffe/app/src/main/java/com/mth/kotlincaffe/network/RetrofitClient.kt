package com.mth.kotlincaffe.network

import com.mth.kotlincaffe.entity.User
import retrofit2.Call
import retrofit2.http.*


interface RetrofitClient {
    @FormUrlEncoded
    @POST("/simpleregister.php")
    fun getUserRegi(
        @Field("name") name: String,
        @Field("hobby") hobby: String,
        @Field("username") uname: String,
        @Field("password") password: String
    ): Call<String>

    @FormUrlEncoded
    @POST("/simplelogin.php")
    fun getUserLogin(
        @Field("username") uname: String,
        @Field("password") password: String
    ): Call<String>

    @GET("/users.php")
    fun getUserList(
    ):Call<MutableList<User>>
}



