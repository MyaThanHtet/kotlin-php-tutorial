package com.mth.kotlincaffe


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mth.kotlincaffe.network.RetrofitClient
import com.mth.kotlincaffe.network.ServiceBuilder
import com.mth.kotlincaffe.ui.LoginActivity
import com.mth.kotlincaffe.ui.PreferenceHelper
import com.mth.kotlincaffe.ui.WelcomeActivity
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : AppCompatActivity() {
    private lateinit var etname: EditText
    private lateinit var ethobby: EditText
    private lateinit var etusername: EditText
    private lateinit var etpassword: EditText
    private lateinit var btnregister: Button
    private lateinit var tvlogin: TextView
    private lateinit var preferenceHelper: PreferenceHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_layout)

        preferenceHelper = PreferenceHelper(this)

        if (preferenceHelper.isLogin) {
            val intent = Intent(this@MainActivity, WelcomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        etname = findViewById(R.id.etname)
        ethobby = findViewById(R.id.ethobby)
        etusername = findViewById(R.id.etusername)
        etpassword = findViewById(R.id.etpassword)
        btnregister = findViewById(R.id.btn)
        tvlogin = findViewById(R.id.tvLogin)

        tvlogin.setOnClickListener {
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        btnregister.setOnClickListener {
            registerMe()
        }
    }

    private fun registerMe() {
        val name = etname.text.toString()
        val hobby = ethobby.text.toString()
        val username = etusername.text.toString()
        val password = etpassword.text.toString()

        val retrofit = ServiceBuilder.buildService(RetrofitClient::class.java)

        retrofit.getUserRegi(name, hobby, username, password).enqueue(
            object : Callback<String> {
                override fun onFailure(call: Call<String>, t: Throwable) {
                    Log.i(MainActivity::class.simpleName, "on FAILURE!!!!$t")
                }

                override fun onResponse(call: Call<String>, response: Response<String>) {

                    val jsonresponse: String = response.body().toString()
                    parseRegData(jsonresponse)
                    Log.i("RETROFITRESULT", jsonresponse)
                }
            }
        )

        /* val retrofit: Retrofit = Retrofit.Builder()
             .baseUrl(BASEURL)
             .addConverterFactory(GsonConverterFactory.create())
             .build()
         val api: RetrofitClient = retrofit.create(RetrofitClient::class.java)
         val call: Call<String> = api.getUserRegi(name, hobby, username, password)
         call?.enqueue(object : Callback<String> {
             override fun onResponse(call: Call<String>, response: Response<String>) {
                 Log.i("ResponseString", response.body().toString())
                 if (response.isSuccessful) {
                     if (response.body() != null) {
                         Log.i("onSuccess", response.body().toString())
                         val jsonresponse: String = response.body().toString()
                         try {
                             parseRegData(jsonresponse)
                         } catch (e: JSONException) {
                             e.printStackTrace()
                         }
                     } else {
                         Log.i(
                             "onEmptyResponse",
                             "Returned empty response"
                         )
                     }
                 }
             }

             override fun onFailure(call: Call<String>, t: Throwable) {

             }

         })*/
    }

    @Throws(JSONException::class)
    private fun parseRegData(response: String) {
        val jsonObject = JSONObject(response)
        if (jsonObject.optString("status") == "true") {
            saveInfo(response)
            Toast.makeText(this@MainActivity, "Registered Successfully!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, WelcomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this@MainActivity, jsonObject.getString("message"), Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun saveInfo(response: String) {
        preferenceHelper.putIsLogin(true)
        try {
            val jsonObject = JSONObject(response)
            if (jsonObject.getString("status") == "true") {
                val dataArray = jsonObject.getJSONArray("data")
                for (i in 0 until dataArray.length()) {
                    val dataobj = dataArray.getJSONObject(i)
                    preferenceHelper.putName(dataobj.getString("name"))
                    preferenceHelper.putHobby(dataobj.getString("hobby"))
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }
}

